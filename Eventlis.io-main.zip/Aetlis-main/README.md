# Aetlis.io an Ogarcpp Modification


## Features
* Complete: Pretty much everything in OgarII besides team mode.
* Complete: Solotricks now works perfectly
* Complete: crash issues fixed mostly w/mutex.
* Complete: Added serverside linesplit projection, using resolverigid.
* Shit ass admin commands, teleport, ban, kick, mute, mass, virus
* Fast: Accelerated physics calculation with multithreading.
* Fun: Bot AI is dumb cuz i broke it.

## Install & Build
* ### Windows
  VS2019
* ### Linux
  CMake
